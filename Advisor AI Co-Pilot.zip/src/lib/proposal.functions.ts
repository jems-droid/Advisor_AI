import { createServerFn } from "@tanstack/react-start";
import { GoogleGenAI } from "@google/genai";

import {
  HORIZON_LABELS,
  RISK_LABELS,
  SYSTEM_PROMPT,
  type Horizon,
  type MeetingInput,
  type Proposal,
} from "./proposal";

const HORIZONS: Horizon[] = ["short", "medium", "long"];

function stripFences(text: string) {
  return text
    .replace(/^```(?:json)?/i, "")
    .replace(/```$/, "")
    .trim();
}

export const generateProposal = createServerFn({ method: "POST" })
  .inputValidator((input: MeetingInput): MeetingInput => {
    const clientName = String(input?.clientName ?? "").trim();
    const notes = String(input?.notes ?? "").trim();
    if (!clientName) throw new Error("Client name is required.");
    if (!notes) throw new Error("Meeting notes are required.");
    const horizon = HORIZONS.includes(input?.horizon) ? input.horizon : "medium";
    const risk = Math.min(5, Math.max(1, Math.round(Number(input?.risk) || 3)));
    const age = Math.min(100, Math.max(18, Math.round(Number(input?.age) || 35)));
    return { clientName, notes, horizon, risk, age };
  })
  .handler(async ({ data }): Promise<Proposal> => {
    const apiKey = process.env["GEMINI_API_KEY"];
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is not configured on the server.");
    }

    const ai = new GoogleGenAI({ apiKey });

    const userPrompt = `Client Name: ${data.clientName}
Age: ${data.age}
Investment Horizon: ${HORIZON_LABELS[data.horizon]}
Risk Comfort: ${RISK_LABELS[data.risk - 1]} (${data.risk}/5)
Post-Meeting Vague Notes: ${data.notes}`;

    let text = "";
    let lastError: unknown;
    for (let attempt = 0; attempt < 3; attempt++) {
      try {
        const response = await ai.models.generateContent({
          model: "gemini-3.5-flash",
          contents: userPrompt,
          config: {
            systemInstruction: SYSTEM_PROMPT,
            responseMimeType: "application/json",
            temperature: 0.7,
          },
        });
        text = response.text ?? "";
        lastError = undefined;
        break;
      } catch (error) {
        lastError = error;
        console.error(`Gemini call failed (attempt ${attempt + 1})`, error);
        await new Promise((r) => setTimeout(r, 800 * (attempt + 1)));
      }
    }

    if (lastError) {
      throw new Error(
        "Could not reach the AI service just now. Please check your connection and try again.",
      );
    }

    try {
      return JSON.parse(stripFences(text)) as Proposal;
    } catch {
      throw new Error("Could not read the AI response. Please try generating again.");
    }
  });

