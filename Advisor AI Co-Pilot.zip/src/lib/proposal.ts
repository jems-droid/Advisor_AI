export type Horizon = "short" | "medium" | "long";

export interface MeetingInput {
  clientName: string;
  age: number;
  horizon: Horizon;
  risk: number; // 1 (Conservative) - 5 (Aggressive)
  notes: string;
}

export interface Allocation {
  label: string;
  percent: number;
  note: string;
}

export interface Proposal {
  profileSummary: string;
  goals: string[];
  talkingPoints: string[];
  allocation: Allocation[];
  whatsappMessage: string;
}

export const RISK_LABELS = [
  "Conservative",
  "Moderately Conservative",
  "Balanced",
  "Moderately Aggressive",
  "Aggressive",
];

export const HORIZON_LABELS: Record<Horizon, string> = {
  short: "Short (< 3 yrs)",
  medium: "Medium (3-7 yrs)",
  long: "Long (> 7 yrs)",
};

export const SYSTEM_PROMPT = `You are "Advisor Co-Pilot", an assistant for an Indian AMFI-registered Mutual Fund Distributor (MFD).
From a client's basic profile and the advisor's rough post-meeting notes, produce a client-ready proposal.

Rules:
- Use Indian context: SIP, STP, ELSS, liquid/arbitrage funds, debt funds, index funds, flexi-cap, hybrid funds. Amounts in INR (₹, lakh, crore).
- NEVER name specific AMCs or scheme names. Use category-level guidance only.
- Keep language simple, warm and jargon-light. The advisor will read the talking points aloud.
- Asset allocation must total exactly 100 and reflect the horizon + risk comfort. Short horizon money stays in debt/arbitrage.
- Include a short standard disclaimer inside the WhatsApp message ("Mutual fund investments are subject to market risks...").

Return ONLY valid JSON matching this shape:
{
  "profileSummary": "2 sentence summary of the client",
  "goals": ["short goal extracted from notes", "..."],
  "talkingPoints": ["5-7 crisp bullets the advisor can say out loud"],
  "allocation": [{"label":"Equity","percent":60,"note":"one line why"}],
  "whatsappMessage": "client-friendly follow-up message with emojis and line breaks"
}`;
