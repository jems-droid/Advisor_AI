import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import {
  ArrowLeft,
  Copy,
  Loader2,
  MessageCircle,
  Share2,
  Sparkles,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import { useServerFn } from "@tanstack/react-start";
import {
  HORIZON_LABELS,
  RISK_LABELS,
  type Horizon,
  type Proposal,
} from "@/lib/proposal";
import { generateProposal } from "@/lib/proposal.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Advisor Co-Pilot — Client Proposals for Indian MFDs" },
      {
        name: "description",
        content:
          "Turn rough post-meeting notes into a client-ready mutual fund proposal: profile summary, talking points, asset allocation and a WhatsApp follow-up.",
      },
      { property: "og:title", content: "Advisor Co-Pilot for Mutual Fund Distributors" },
      {
        property: "og:description",
        content:
          "AI co-pilot that turns vague meeting notes into talking points, asset allocation and a ready-to-send WhatsApp follow-up.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const CHART_TONES = ["bg-chart-1", "bg-chart-2", "bg-chart-3", "bg-chart-4", "bg-chart-5"];

function Index() {
  const [clientName, setClientName] = useState("");
  const [age, setAge] = useState("");
  const [horizon, setHorizon] = useState<Horizon>("medium");
  const [risk, setRisk] = useState(3);
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [proposal, setProposal] = useState<Proposal | null>(null);
  const runGenerateProposal = useServerFn(generateProposal);

  async function handleGenerate() {
    if (!clientName.trim() || !notes.trim()) {
      toast.error("Add the client name and your meeting notes first.");
      return;
    }
    setLoading(true);
    try {
      const result = await runGenerateProposal({
        data: {
          clientName: clientName.trim(),
          age: Number(age) || 35,
          horizon,
          risk,
          notes: notes.trim(),
        },
      });
      setProposal(result);
      window.scrollTo({ top: 0 });
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Could not generate the proposal.");
    } finally {
      setLoading(false);
    }
  }

  async function copyWhatsapp() {
    if (!proposal) return;
    try {
      await navigator.clipboard.writeText(proposal.whatsappMessage);
      toast.success("WhatsApp follow-up copied", {
        description: "Paste it straight into the client's chat.",
      });
    } catch {
      toast.error("Clipboard blocked by the browser.");
    }
  }

  async function shareOrExport() {
    if (!proposal) return;
    const text = `${clientName} — Proposal\n\n${proposal.profileSummary}\n\nTalking points:\n${proposal.talkingPoints
      .map((p) => `• ${p}`)
      .join("\n")}\n\nAllocation:\n${proposal.allocation
      .map((a) => `${a.label}: ${a.percent}%`)
      .join("\n")}`;
    if (navigator.share) {
      try {
        await navigator.share({ title: `${clientName} — Proposal`, text });
        return;
      } catch {
        /* user dismissed */
      }
    }
    window.print();
  }

  return (
    <main className="min-h-screen pb-20">
      <header className="bg-hero-gradient px-5 pb-10 pt-9 text-primary-foreground">
        <div className="mx-auto max-w-xl">
          <Badge variant="secondary" className="mb-3 gap-1.5 rounded-full">
            <Sparkles className="size-3.5" /> AI Co-Pilot
          </Badge>
          <h1 className="text-3xl font-bold leading-tight">Advisor Co-Pilot</h1>
          <p className="mt-2 text-sm opacity-85">
            Turn messy post-meeting notes into a clean, client-ready mutual fund proposal.
          </p>
        </div>
      </header>

      <div className="mx-auto -mt-6 max-w-xl px-4">
        {proposal ? (
          <Results
            proposal={proposal}
            clientName={clientName}
            age={age}
            horizon={horizon}
            risk={risk}
            onBack={() => setProposal(null)}
            onCopy={copyWhatsapp}
            onShare={shareOrExport}
          />
        ) : (
          <Card className="shadow-elevated">
            <CardHeader>
              <CardTitle className="text-lg">Meeting input</CardTitle>
            </CardHeader>
            <CardContent className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="name">Client name</Label>
                <Input
                  id="name"
                  value={clientName}
                  onChange={(e) => setClientName(e.target.value)}
                  placeholder="Ramesh Iyer"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="age">Age</Label>
                <Input
                  id="age"
                  type="number"
                  inputMode="numeric"
                  value={age}
                  onChange={(e) => setAge(e.target.value)}
                  placeholder="38"
                />
              </div>

              <div className="space-y-2">
                <Label>Investment horizon</Label>
                <Select value={horizon} onValueChange={(v) => setHorizon(v as Horizon)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="short">{HORIZON_LABELS.short}</SelectItem>
                    <SelectItem value="medium">{HORIZON_LABELS.medium}</SelectItem>
                    <SelectItem value="long">{HORIZON_LABELS.long}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-3">
                <div className="flex items-baseline justify-between">
                  <Label>Risk comfort</Label>
                  <span className="text-sm font-semibold text-primary">
                    {RISK_LABELS[risk - 1]}
                  </span>
                </div>
                <Slider
                  min={1}
                  max={5}
                  step={1}
                  value={[risk]}
                  onValueChange={([v]) => setRisk(v ?? 3)}
                />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Conservative</span>
                  <span>Aggressive</span>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="notes">Post-meeting vague notes</Label>
                <Textarea
                  id="notes"
                  rows={6}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="e.g. Wants to buy car in 2 yrs, save for kid college, worried about market crashes"
                />
              </div>

              <Button
                size="lg"
                className="h-13 w-full text-base"
                onClick={handleGenerate}
                disabled={loading}
              >
                {loading ? (
                  <>
                    <Loader2 className="size-4 animate-spin" /> Preparing proposal…
                  </>
                ) : (
                  <>
                    <Sparkles className="size-4" /> Generate client proposal
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        )}
      </div>
    </main>
  );
}

function Results({
  proposal,
  clientName,
  age,
  horizon,
  risk,
  onBack,
  onCopy,
  onShare,
}: {
  proposal: Proposal;
  clientName: string;
  age: string;
  horizon: Horizon;
  risk: number;
  onBack: () => void;
  onCopy: () => void;
  onShare: () => void;
}) {
  return (
    <div className="space-y-4">
      <Card className="shadow-elevated">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between gap-3">
            <CardTitle className="text-xl">{clientName}</CardTitle>
            <Button variant="ghost" size="sm" onClick={onBack}>
              <ArrowLeft className="size-4" /> Edit
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap gap-2">
            {age ? <Badge variant="secondary">{age} yrs</Badge> : null}
            <Badge variant="secondary">{HORIZON_LABELS[horizon]}</Badge>
            <Badge variant="secondary">{RISK_LABELS[risk - 1]}</Badge>
          </div>
          <p className="text-sm leading-relaxed text-muted-foreground">
            {proposal.profileSummary}
          </p>
          {proposal.goals?.length ? (
            <div className="flex flex-wrap gap-2 pt-1">
              {proposal.goals.map((g) => (
                <Badge key={g} variant="outline" className="rounded-full font-normal">
                  {g}
                </Badge>
              ))}
            </div>
          ) : null}
        </CardContent>
      </Card>

      <Card className="shadow-elevated">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Talking points</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {proposal.talkingPoints?.map((point, i) => (
              <li key={i} className="flex gap-3 text-sm leading-relaxed">
                <span className="mt-0.5 flex size-5 shrink-0 items-center justify-center rounded-full bg-secondary text-[11px] font-bold text-secondary-foreground">
                  {i + 1}
                </span>
                {point}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        {proposal.allocation?.map((slice, i) => (
          <Card key={slice.label} className="shadow-elevated">
            <CardContent className="space-y-2 p-4">
              <p className="text-sm font-medium text-muted-foreground">{slice.label}</p>
              <p className="font-display text-3xl font-bold">{slice.percent}%</p>
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-muted">
                <div
                  className={`h-full rounded-full ${CHART_TONES[i % CHART_TONES.length]}`}
                  style={{ width: `${slice.percent}%` }}
                />
              </div>
              <p className="text-xs leading-snug text-muted-foreground">{slice.note}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="shadow-elevated">
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center gap-2 text-base">
            <MessageCircle className="size-4" /> WhatsApp follow-up
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="whitespace-pre-wrap rounded-xl bg-muted p-3 text-sm leading-relaxed">
            {proposal.whatsappMessage}
          </p>
        </CardContent>
      </Card>

      <div className="flex flex-col gap-2 sm:flex-row">
        <Button className="h-12 flex-1" onClick={onCopy}>
          <Copy className="size-4" /> Copy WhatsApp follow-up
        </Button>
        <Button variant="outline" className="h-12 flex-1" onClick={onShare}>
          <Share2 className="size-4" /> Export PDF / Share
        </Button>
      </div>
    </div>
  );
}
